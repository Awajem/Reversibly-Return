import '/flutter_flow/flutter_flow_util.dart';
import 'returns_widget.dart' show ReturnsWidget;
import 'package:flutter/material.dart';

class ReturnsModel extends FlutterFlowModel<ReturnsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
