import '/flutter_flow/flutter_flow_util.dart';
import 'order_process2upload_widget.dart' show OrderProcess2uploadWidget;
import 'package:flutter/material.dart';

class OrderProcess2uploadModel
    extends FlutterFlowModel<OrderProcess2uploadWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
