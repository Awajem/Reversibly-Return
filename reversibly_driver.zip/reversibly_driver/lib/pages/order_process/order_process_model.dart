import '/flutter_flow/flutter_flow_util.dart';
import 'order_process_widget.dart' show OrderProcessWidget;
import 'package:flutter/material.dart';

class OrderProcessModel extends FlutterFlowModel<OrderProcessWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
