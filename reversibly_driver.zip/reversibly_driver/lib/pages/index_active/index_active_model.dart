import '/flutter_flow/flutter_flow_util.dart';
import 'index_active_widget.dart' show IndexActiveWidget;
import 'package:flutter/material.dart';

class IndexActiveModel extends FlutterFlowModel<IndexActiveWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for Switch widget.
  bool? switchValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
