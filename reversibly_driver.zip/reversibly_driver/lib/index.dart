// Export pages
export '/pages/signin/signin_widget.dart' show SigninWidget;
export '/pages/signup/signup_widget.dart' show SignupWidget;
export '/pages/otp/otp_widget.dart' show OtpWidget;
export '/pages/terms/terms_widget.dart' show TermsWidget;
export '/pages/personal_info/personal_info_widget.dart' show PersonalInfoWidget;
export '/pages/vehicle_info/vehicle_info_widget.dart' show VehicleInfoWidget;
export '/pages/index/index_widget.dart' show IndexWidget;
export '/pages/index_active/index_active_widget.dart' show IndexActiveWidget;
export '/pages/index_copy/index_copy_widget.dart' show IndexCopyWidget;
export '/pages/returns/returns_widget.dart' show ReturnsWidget;
export '/pages/reason/reason_widget.dart' show ReasonWidget;
export '/pages/order_process1/order_process1_widget.dart'
    show OrderProcess1Widget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/map/map_widget.dart' show MapWidget;
export '/pages/order_process/order_process_widget.dart' show OrderProcessWidget;
export '/pages/mapstore/mapstore_widget.dart' show MapstoreWidget;
export '/pages/order_process2upload/order_process2upload_widget.dart'
    show OrderProcess2uploadWidget;
export '/pages/wallet/wallet_widget.dart' show WalletWidget;
export '/pages/personal_info_edit/personal_info_edit_widget.dart'
    show PersonalInfoEditWidget;
export '/pages/vehicle_info_edit/vehicle_info_edit_widget.dart'
    show VehicleInfoEditWidget;
