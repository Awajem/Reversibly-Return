import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBAl8pf7sY0dkd0nWZieT0E1E-nge9nD38",
            authDomain: "uber-2ht4ts.firebaseapp.com",
            projectId: "uber-2ht4ts",
            storageBucket: "uber-2ht4ts.appspot.com",
            messagingSenderId: "734744478060",
            appId: "1:734744478060:web:8af2f03104073e1455f349"));
  } else {
    await Firebase.initializeApp();
  }
}
