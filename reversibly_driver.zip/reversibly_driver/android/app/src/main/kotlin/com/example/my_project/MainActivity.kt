package com.mycompany.reversiblydriver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
